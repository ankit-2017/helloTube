import React, {Component} from 'react';
import {View, Text} from 'react-native';
import axios from 'axios';
class Drive extends Component {
    render(){
        return <View>
            <Text>Google Drive photos</Text>
        </View>
    }
}
export default Drive;